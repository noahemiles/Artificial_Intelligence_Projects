javac UI.java
java UI

Follow menu prompts