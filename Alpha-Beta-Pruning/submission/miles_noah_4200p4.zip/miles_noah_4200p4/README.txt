javac *.java
java UI